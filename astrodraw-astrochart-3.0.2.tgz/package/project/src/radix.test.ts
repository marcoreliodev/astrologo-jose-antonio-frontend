import Radix from './radix';
import SVG from './svg';
import default_settings from './settings';

describe('Radix', () => {
  const data = {
    planets: {
      Sun: [0],
      Moon: [90],
    },
    cusps: [0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330]
  };

  it('should draw aspect lines with default colors', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = default_settings;
    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);
    radix.aspects();

    const aspectLines = document.querySelectorAll('#chart-astrology-aspects > line');
    expect(aspectLines[0].getAttribute('stroke')).toBe(default_settings.ASPECTS.square.color);
  });

  it('should draw aspect lines with custom colors via settings', () => {
    document.body.innerHTML = '<div id="chart"></div>';

    const settings = {
      ...default_settings,
      ASPECTS: {
        square: { degree: 90, orbit: 10, color: 'purple' },
      },
    };

    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);
    radix.aspects();

    const aspectLines = document.querySelectorAll('#chart-astrology-aspects > line');
    expect(aspectLines[0].getAttribute('stroke')).toBe('purple');
  });

  test('should draw exactly the externally supplied aspects, without recalculating them', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = default_settings;
    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);

    const customAspects = [
      {
        aspect: { name: 'custom', degree: 90, color: 'blue', orbit: 1 },
        point: { name: 'Sun', position: 0 },
        toPoint: { name: 'Moon', position: 90 },
        precision: '0.0000',
      },
    ];

    radix.aspects(customAspects as any);

    const aspectLines = document.querySelectorAll('#chart-astrology-aspects > line');
    expect(aspectLines.length).toBe(1);
    expect(aspectLines[0].getAttribute('data-name')).toBe('custom');
    expect(aspectLines[0].getAttribute('stroke')).toBe('blue');
  });

  test('should fall back to internal calculation when aspects() is called without arguments', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = default_settings;
    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);
    radix.aspects();

    const aspectLines = document.querySelectorAll('#chart-astrology-aspects > line');
    expect(aspectLines.length).toBeGreaterThan(0);
    expect(aspectLines[0].getAttribute('data-name')).toBe('square');
  });

  test('should use ASPECTS_STROKE (not CUSPS_STROKE) for the aspect lines width', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = { ...default_settings, ASPECTS_STROKE: 3, CUSPS_STROKE: 1 };
    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);
    radix.aspects();

    const aspectLines = document.querySelectorAll('#chart-astrology-aspects > line');
    expect(aspectLines[0].getAttribute('stroke-width')).toBe('3');
  });

  test('should always draw a single unbroken line per house, with no length variation, even when a planet sits exactly on a cusp', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    // Sun sits exactly on cusp 0 (the As), Moon exactly on cusp 90 - the worst case for the
    // old collision-avoidance logic, which used to shrink or nearly erase the line in this situation.
    const settings = default_settings;
    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);
    radix.drawCusps();

    const cuspsLines = document.querySelectorAll('#chart-astrology-radix-cusps > line');
    expect(cuspsLines.length).toBe(12); // exactly one <line> per house, never split into two segments

    const lengths = Array.from(cuspsLines).map((line) => {
      const x1 = parseFloat(line.getAttribute('x1') as string);
      const y1 = parseFloat(line.getAttribute('y1') as string);
      const x2 = parseFloat(line.getAttribute('x2') as string);
      const y2 = parseFloat(line.getAttribute('y2') as string);
      return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    });

    // every house line must have the same length, whether or not a planet sits on top of it
    const [firstLength, ...rest] = lengths;
    rest.forEach((len) => expect(len).toBeCloseTo(firstLength, 5));
    expect(firstLength).toBeGreaterThan(0);
  });

  test('should draw house lines behind the planet symbols (cusps wrapper precedes the planets wrapper in the DOM)', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = default_settings;
    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);
    radix.drawCusps();
    radix.drawPoints();

    const cuspsGroup = document.getElementById('chart-astrology-radix-cusps') as Element;
    const planetsGroup = document.getElementById('chart-astrology-radix-planets') as Element;
    const siblings = Array.from(cuspsGroup.parentNode!.children);
    expect(siblings.indexOf(cuspsGroup)).toBeLessThan(siblings.indexOf(planetsGroup));
  });

  test('should use a thicker, darker line for the As/Ic/Ds/Mc house lines than for the regular houses', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = { ...default_settings, HOUSES_STROKE: 1, SYMBOL_AXIS_STROKE: 3, LINE_COLOR: '#333', AXIS_LINE_COLOR: '#000' };
    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);
    radix.drawCusps();

    const cuspsLines = document.querySelectorAll('#chart-astrology-radix-cusps > line');
    // cusp index 0 is the As (main axis) - thicker and darker
    expect(cuspsLines[0].getAttribute('stroke-width')).toBe('3');
    expect(cuspsLines[0].getAttribute('stroke')).toBe('#000');
    // cusp index 1 is a regular house - uses the normal house settings
    expect(cuspsLines[1].getAttribute('stroke-width')).toBe('1');
    expect(cuspsLines[1].getAttribute('stroke')).toBe('#333');
    // cusps 3, 6, 9 (Ic/Ds/Mc) get the same axis treatment as index 0
    [3, 6, 9].forEach((i) => {
      expect(cuspsLines[i].getAttribute('stroke-width')).toBe('3');
      expect(cuspsLines[i].getAttribute('stroke')).toBe('#000');
    });
  });

  test('should draw house lines out to just before the signs ring when CUSPS_LINES_TO_OUTER_CIRCLE is true, never reaching the true outer circle', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = { ...default_settings, CUSPS_LINES_TO_OUTER_CIRCLE: true };
    const paper = new SVG('chart', 500, 500, settings);
    const radix = new Radix(paper, 500, 500, 500, data, settings);
    radix.drawCusps();

    const cuspsLines = document.querySelectorAll('#chart-astrology-radix-cusps > line');
    const expectedRadius = 500 - (500 / settings.INNER_CIRCLE_RADIUS_RATIO); // boundary of the signs ring

    [0, 1].forEach((i) => {
      const line = cuspsLines[i];
      const endX = parseFloat(line.getAttribute('x2') as string);
      const endY = parseFloat(line.getAttribute('y2') as string);
      const distanceFromCenter = Math.sqrt((endX - 500) ** 2 + (endY - 500) ** 2);
      expect(distanceFromCenter).toBeCloseTo(expectedRadius, 0);
      expect(distanceFromCenter).toBeLessThan(500); // must stay clear of the signs glyphs
    });
  });

  test('should draw degrees (baseline), minutes (superscript) and retrograde symbol as separate, symbol-free text nodes', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = { ...default_settings, SHOW_DEGREES_MINUTES: true };
    const paper = new SVG('chart', 500, 500, settings);
    const retroData = {
      planets: { Saturn: [19.516667, -1] },
      cusps: data.cusps,
    };
    const radix = new Radix(paper, 500, 500, 500, retroData, settings);
    radix.drawPoints();

    const texts = Array.from(document.querySelectorAll('#chart-astrology-radix-planets > text'));
    const contents = texts.map((t) => t.textContent);
    expect(contents).toContain('19');
    expect(contents).toContain('31');
    expect(contents).toContain('\u211E');
    // no ° or ' symbols anywhere
    expect(contents.some((t) => t?.includes('°') || t?.includes('\''))).toBe(false);

    const degreesEl = texts.find((t) => t.textContent === '19')!;
    const minutesEl = texts.find((t) => t.textContent === '31')!;
    const retroEl = texts.find((t) => t.textContent === '\u211E')!;
    // minutes sit above degrees (smaller y), retrograde sits above minutes (smaller y still)
    expect(parseFloat(minutesEl.getAttribute('y') as string)).toBeLessThan(parseFloat(degreesEl.getAttribute('y') as string));
    expect(parseFloat(retroEl.getAttribute('y') as string)).toBeLessThan(parseFloat(minutesEl.getAttribute('y') as string));
  });

  test('should not draw a retrograde text node when the planet is direct', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = { ...default_settings, SHOW_DEGREES_MINUTES: true };
    const paper = new SVG('chart', 500, 500, settings);
    const directData = { planets: { Saturn: [19.516667, 1] }, cusps: data.cusps };
    const radix = new Radix(paper, 500, 500, 500, directData, settings);
    radix.drawPoints();

    const texts = Array.from(document.querySelectorAll('#chart-astrology-radix-planets > text')).map((t) => t.textContent);
    expect(texts).not.toContain('\u211E');
  });

  test('should not draw the degrees/minutes block when SHOW_DEGREES_MINUTES is false (default)', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = default_settings;
    const paper = new SVG('chart', 500, 500, settings);
    const soloData = { planets: { Saturn: [19.516667] }, cusps: data.cusps };
    const radix = new Radix(paper, 500, 500, 500, soloData, settings);
    radix.drawPoints();

    const texts = Array.from(document.querySelectorAll('#chart-astrology-radix-planets > text')).map((t) => t.textContent);
    expect(texts.some((t) => t?.includes('°') || t?.includes('\u211E'))).toBe(false);
  });

  describe('addPointsOfInterest - degrees/minutes on As/Ds/Mc/Ic', () => {
    test('should draw baseline degrees + superscript minutes for each angle when given the extended {longitude, degree, minute} format', () => {
      document.body.innerHTML = '<div id="chart"></div>';
      const settings = default_settings;
      const paper = new SVG('chart', 500, 500, settings);
      const radix = new Radix(paper, 500, 500, 500, data, settings);

      radix.addPointsOfInterest({
        As: { longitude: 0, degree: 13, minute: 24 },
        Ic: { longitude: 90, degree: 12, minute: 47 },
        Ds: { longitude: 180, degree: 13, minute: 24 },
        Mc: { longitude: 270, degree: 12, minute: 47 },
      });
      radix.drawAxis();

      const texts = Array.from(document.querySelectorAll('#chart-astrology-radix-axis > text'));
      const contents = texts.map((t) => t.textContent);

      // 4 angles x 2 text nodes each (degrees + minutes), no ° or ' symbols, no retrograde symbol
      expect(texts.length).toBe(8);
      expect(contents).toEqual(expect.arrayContaining(['13', '24', '12', '47']));
      expect(contents.some((t) => t?.includes('°') || t?.includes('\'') || t?.includes('\u211E'))).toBe(false);

      const degreesEl = texts.find((t) => t.textContent === '13')!;
      const minutesEl = texts.find((t) => t.textContent === '24')!;
      expect(parseFloat(minutesEl.getAttribute('y') as string)).toBeLessThan(parseFloat(degreesEl.getAttribute('y') as string));
      expect(parseFloat(minutesEl.getAttribute('font-size') as string)).toBeLessThan(parseFloat(degreesEl.getAttribute('font-size') as string));
    });

    test('should draw As/Ds degrees below their symbol, and Mc/Ic degrees to the side of theirs', () => {
      document.body.innerHTML = '<div id="chart"></div>';
      const settings = default_settings;
      const paper = new SVG('chart', 500, 500, settings);
      const radix = new Radix(paper, 500, 500, 500, data, settings);

      // capture each angle's own symbol position by calling drawAngleDegreesMinutes directly
      // against a known point, bypassing the exact placement math in drawAxis()
      const point = { x: 250, y: 250 };
      (radix as any).pointsOfInterestDegreesMinutes.As = { degree: 13, minute: 24 };
      (radix as any).pointsOfInterestDegreesMinutes.Mc = { degree: 12, minute: 47 };

      const wrapperBelow = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      radix.drawAngleDegreesMinutes(wrapperBelow, 'As', point, 'below');
      const belowTexts = Array.from(wrapperBelow.querySelectorAll('text'));
      const belowDegrees = belowTexts.find((t) => t.textContent === '13')!;

      const wrapperRight = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      radix.drawAngleDegreesMinutes(wrapperRight, 'Mc', point, 'right');
      const rightTexts = Array.from(wrapperRight.querySelectorAll('text'));
      const rightDegrees = rightTexts.find((t) => t.textContent === '12')!;

      // below: pushed down (larger y), roughly centered on x
      expect(parseFloat(belowDegrees.getAttribute('y') as string)).toBeGreaterThan(point.y);
      expect(Math.abs(parseFloat(belowDegrees.getAttribute('x') as string) - point.x)).toBeLessThan(10);

      // right: same y as the point, offset to the right (larger x)
      expect(parseFloat(rightDegrees.getAttribute('y') as string)).toBe(point.y);
      expect(parseFloat(rightDegrees.getAttribute('x') as string)).toBeGreaterThan(point.x);
    });

    test('getAxisSymbolAnchor should shift the anchor to match each glyph\'s actual rendered footprint, not the raw placement point', () => {
      document.body.innerHTML = '<div id="chart"></div>';
      const settings = default_settings;
      const paper = new SVG('chart', 500, 500, settings);
      const radix = new Radix(paper, 500, 500, 500, data, settings);
      const raw = { x: 100, y: 100 };

      // Mc/Ic glyphs render well to the right of the raw anchor (svg.ts bakes in a ~19-22px
      // internal shift) - the corrected anchor must account for that, or 'right' layout
      // would place the degrees text on top of, or to the left of, the visible letters.
      const mcAnchor = radix.getAxisSymbolAnchor('Mc', raw, 'right');
      const icAnchor = radix.getAxisSymbolAnchor('Ic', raw, 'right');
      expect(mcAnchor.x).toBeGreaterThan(raw.x + 15);
      expect(icAnchor.x).toBeGreaterThan(raw.x + 15);

      // As/Ds 'below' anchor must be shifted down past the glyph's own bottom edge
      const asAnchor = radix.getAxisSymbolAnchor('As', raw, 'below');
      const dsAnchor = radix.getAxisSymbolAnchor('Ds', raw, 'below');
      expect(asAnchor.y).toBeGreaterThan(raw.y);
      expect(dsAnchor.y).toBeGreaterThan(raw.y);
    });

    test('rendered Mc degrees should sit clear of the glyph\'s own bounding box, to its right - not overlapping or underneath it', () => {
      document.body.innerHTML = '<div id="chart"></div>';
      const settings = default_settings;
      const paper = new SVG('chart', 500, 500, settings);
      const radix = new Radix(paper, 500, 500, 500, data, settings);

      const rawAnchor = { x: 200, y: 150 };
      const wrapper = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      wrapper.appendChild(paper.getSymbol(settings.SYMBOL_MC, rawAnchor.x, rawAnchor.y));
      (radix as any).pointsOfInterestDegreesMinutes.Mc = { degree: 12, minute: 47 };
      radix.drawAngleDegreesMinutes(wrapper, 'Mc', radix.getAxisSymbolAnchor('Mc', rawAnchor, 'right'), 'right');

      // compute the Mc glyph's bounding box directly from its path 'd' attribute
      const mcPath = wrapper.querySelector('path')!;
      const d = mcPath.getAttribute('d') as string;
      const nums = d.replace(/^m\s*/, '').split(/[\s,]+/).map(Number).filter((n) => !isNaN(n));
      let cx = nums[0]; let cy = nums[1];
      let maxX = cx; let minY = cy; let maxY = cy;
      for (let i = 2; i < nums.length; i += 2) {
        cx += nums[i]; cy += nums[i + 1];
        maxX = Math.max(maxX, cx);
        minY = Math.min(minY, cy);
        maxY = Math.max(maxY, cy);
      }

      const degreesText = Array.from(wrapper.querySelectorAll('text')).find((t) => t.textContent === '12')!;
      const textX = parseFloat(degreesText.getAttribute('x') as string);
      const textY = parseFloat(degreesText.getAttribute('y') as string);

      expect(textX).toBeGreaterThan(maxX); // clear to the right of the glyph
      expect(textY).toBeGreaterThanOrEqual(minY - 2); // roughly the same vertical band as the glyph
      expect(textY).toBeLessThanOrEqual(maxY + 2); // not shoved far below it
    });

    test('should not draw any degrees/minutes text when using the legacy number[] format (unchanged behavior)', () => {
      document.body.innerHTML = '<div id="chart"></div>';
      const settings = default_settings;
      const paper = new SVG('chart', 500, 500, settings);
      const radix = new Radix(paper, 500, 500, 500, data, settings);

      radix.addPointsOfInterest({
        As: [0],
        Ic: [90],
        Ds: [180],
        Mc: [270],
      });
      radix.drawAxis();

      const texts = document.querySelectorAll('#chart-astrology-radix-axis > text');
      expect(texts.length).toBe(0);
    });

    test('should not draw degrees/minutes when the extended format is given without both degree and minute', () => {
      document.body.innerHTML = '<div id="chart"></div>';
      const settings = default_settings;
      const paper = new SVG('chart', 500, 500, settings);
      const radix = new Radix(paper, 500, 500, 500, data, settings);

      radix.addPointsOfInterest({
        As: { longitude: 0 },
      });
      radix.drawAxis();

      const texts = document.querySelectorAll('#chart-astrology-radix-axis > text');
      expect(texts.length).toBe(0);
    });

    test('should still populate toPoints with the longitude for aspect calculations, in both formats', () => {
      document.body.innerHTML = '<div id="chart"></div>';
      const settings = default_settings;
      const paper = new SVG('chart', 500, 500, settings);
      const radix = new Radix(paper, 500, 500, 500, data, settings);

      radix.addPointsOfInterest({
        As: { longitude: 43.3994, degree: 13, minute: 24 },
        Mc: [312.7834],
      });

      expect(radix.toPoints.As).toEqual([43.3994]);
      expect(radix.toPoints.Mc).toEqual([312.7834]);
    });
  });

  test('should draw every planet symbol before any degree/minute text, so a label can never end up hidden behind a neighboring planet symbol', () => {
    document.body.innerHTML = '<div id="chart"></div>';
    const settings = { ...default_settings, SHOW_DEGREES_MINUTES: true };
    const paper = new SVG('chart', 500, 500, settings);
    // Sun and Moon sit close together (0 and 5 degrees apart) - a common stellium scenario
    const closeData = { planets: { Sun: [0, 1], Moon: [5, 1] }, cusps: data.cusps };
    const radix = new Radix(paper, 500, 500, 500, closeData, settings);
    radix.drawPoints();

    const children = Array.from(document.querySelectorAll('#chart-astrology-radix-planets > *'));
    const lastSymbolIndex = children.reduce((last, el, i) => (el.tagName === 'g' ? i : last), -1);
    const firstTextIndex = children.findIndex((el) => el.tagName === 'text');

    expect(lastSymbolIndex).toBeGreaterThanOrEqual(0);
    expect(firstTextIndex).toBeGreaterThan(lastSymbolIndex);
  });
});
