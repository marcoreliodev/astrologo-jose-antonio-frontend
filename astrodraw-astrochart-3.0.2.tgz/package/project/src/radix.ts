import Zodiac from './zodiac'
import AspectCalculator from './aspect'
import type { FormedAspect } from './aspect'
import Transit from './transit'
import {
  validate
  , radiansToDegree
  , getEmptyWrapper
  , getPointPosition
  , getRulerPositions
  , getDescriptionPosition
  , assemble
  , getDegreesAndMinutes
  , getDegreesMinutesLayout
  , formatDegreesMinutesValues
} from './utils'
import type SVG from './svg'
import type { Settings } from './settings'

export type Points = Record<string, number[]>
export interface PointOfInterestWithDegrees { longitude: number; degree?: number; minute?: number }
export type PointOfInterestValue = number[] | PointOfInterestWithDegrees
export type PointsOfInterestInput = Record<string, PointOfInterestValue>
export interface LocatedPoint { name: string; x: number; y: number; r: number; angle: number; pointer?: number; index?: number }
export interface AstroData {
  planets: Points
  cusps: number[]
}

/**
   * Radix charts.
   *
   * @class
   * @public
   * @constructor
    * @param {this.settings.SVG} paper
   * @param {int} cx
   * @param {int} cy
   * @param {int} radius
   * @param {Object} data
   */
class Radix {
  settings: Settings
  data: AstroData
  paper: SVG
  cx: number
  cy: number
  radius: number
  locatedPoints: LocatedPoint[]
  rulerRadius: number
  pointRadius: number
  toPoints: Points
  pointsOfInterestDegreesMinutes: Record<string, { degree: number; minute: number }>
  shift: number
  universe: Element
  context: this
  constructor(paper: SVG, cx: number, cy: number, radius: number, data: AstroData, settings: Settings) {
    this.settings = settings
    // Validate data
    const status = validate(data)
    if (status.hasError) {
      throw new Error(status.messages.join(' | '))
    }

    this.data = data
    this.paper = paper
    this.cx = cx
    this.cy = cy
    this.radius = radius

    // after calling this.drawPoints() it contains current position of point
    this.locatedPoints = []
    this.rulerRadius = ((this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO) / this.settings.RULER_RADIUS)
    this.pointRadius = this.radius - (this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO + 2 * this.rulerRadius + (this.settings.PADDING * this.settings.SYMBOL_SCALE))

    // @see aspects()
    // @see setPointsOfInterest()
    this.toPoints = JSON.parse(JSON.stringify(this.data.planets)) // Clone object
    this.pointsOfInterestDegreesMinutes = {}

    this.shift = 0
    if (this.data.cusps && this.data.cusps[0]) {
      const deg360 = radiansToDegree(2 * Math.PI)
      this.shift = deg360 - this.data.cusps[0]
    }

    // preparing wrapper for aspects. It is the lowest layer
    const divisionForAspects = document.createElementNS(this.paper.root.namespaceURI, 'g')
    divisionForAspects.setAttribute('id', this.paper.root.id + '-' + this.settings.ID_ASPECTS)
    this.paper.root.appendChild(divisionForAspects)

    this.universe = document.createElementNS(this.paper.root.namespaceURI, 'g')
    this.universe.setAttribute('id', this.paper.root.id + '-' + this.settings.ID_RADIX)
    this.paper.root.appendChild(this.universe)

    this.context = this
  }

  /**
   * Draw background
   */
  drawBg(): void {
    const universe = this.universe
    const wrapper = getEmptyWrapper(universe, this.paper.root.id + '-' + this.settings.ID_BG, this.paper.root.id)

    const LARGE_ARC_FLAG = 1
    const start = 0 // degree
    const end = 359.99 // degree
    const hemisphere = this.paper.segment(this.cx, this.cy, this.radius - this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO, start, end, this.radius / this.settings.INDOOR_CIRCLE_RADIUS_RATIO, LARGE_ARC_FLAG)
    hemisphere.setAttribute('fill', this.settings.STROKE_ONLY ? 'none' : this.settings.COLOR_BACKGROUND)
    wrapper.appendChild(hemisphere)
  }

  /**
   * Draw universe.
   */
  drawUniverse(): void {
    const universe = this.universe
    const wrapper = getEmptyWrapper(universe, this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_SIGNS, this.paper.root.id)

    // colors
    for (let i = 0, step = 30, start = this.shift, len = this.settings.COLORS_SIGNS.length; i < len; i++) {
      const segment = this.paper.segment(this.cx, this.cy, this.radius, start, start + step, this.radius - this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO)
      segment.setAttribute('fill', this.settings.STROKE_ONLY ? 'none' : this.settings.COLORS_SIGNS[i])
      segment.setAttribute('id', this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_SIGNS + '-' + i)
      segment.setAttribute('stroke', this.settings.STROKE_ONLY ? this.settings.CIRCLE_COLOR : 'none')
      segment.setAttribute('stroke-width', this.settings.STROKE_ONLY ? '1' : '0')
      wrapper.appendChild(segment)

      start += step
    }

    // signs
    for (let i = 0, step = 30, start = 15 + this.shift, len = this.settings.SYMBOL_SIGNS.length; i < len; i++) {
      const position = getPointPosition(this.cx, this.cy, this.radius - (this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO) / 2, start, this.settings)
      wrapper.appendChild(this.paper.getSymbol(this.settings.SYMBOL_SIGNS[i], position.x, position.y))
      start += step
    }
  }

  /**
   * Draw points
   */
  drawPoints(): void {
    if (this.data.planets == null) {
      return
    }

    const universe = this.universe
    const wrapper = getEmptyWrapper(universe, this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_POINTS, this.paper.root.id)

    const gap = this.radius - (this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO + this.radius / this.settings.INDOOR_CIRCLE_RADIUS_RATIO)
    const step = (gap - 2 * (this.settings.PADDING * this.settings.SYMBOL_SCALE)) / Object.keys(this.data.planets).length

    const pointerRadius = this.radius - (this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO + this.rulerRadius)
    let startPosition
    let endPosition

    for (const planet in this.data.planets) {
      if (this.data.planets.hasOwnProperty(planet)) {
        const position = getPointPosition(this.cx, this.cy, this.pointRadius, this.data.planets[planet][0] + this.shift, this.settings)
        const point = { name: planet, x: position.x, y: position.y, r: (this.settings.COLLISION_RADIUS * this.settings.SYMBOL_SCALE), angle: this.data.planets[planet][0] + this.shift, pointer: this.data.planets[planet][0] + this.shift }
        this.locatedPoints = assemble(this.locatedPoints, point, { cx: this.cx, cy: this.cy, r: this.pointRadius }, this.settings)
      }
    }

    if (this.settings.DEBUG) console.log('Radix count of points: ' + this.locatedPoints.length)
    if (this.settings.DEBUG) console.log('Radix located points:\n' + JSON.stringify(this.locatedPoints))

    this.locatedPoints.forEach(function (point: LocatedPoint) {
      // draw pointer
      startPosition = getPointPosition(this.cx, this.cy, pointerRadius, this.data.planets[point.name][0] + this.shift, this.settings)
      endPosition = getPointPosition(this.cx, this.cy, pointerRadius - this.rulerRadius / 2, this.data.planets[point.name][0] + this.shift, this.settings)
      const pointer = this.paper.line(startPosition.x, startPosition.y, endPosition.x, endPosition.y)
      pointer.setAttribute('stroke', this.settings.CIRCLE_COLOR)
      pointer.setAttribute('stroke-width', (this.settings.CUSPS_STROKE * this.settings.SYMBOL_SCALE))
      wrapper.appendChild(pointer)

      // draw pointer line
      if (!this.settings.STROKE_ONLY && (this.data.planets[point.name][0] + this.shift) !== point.angle) {
        startPosition = endPosition
        endPosition = getPointPosition(this.cx, this.cy, this.pointRadius + (this.settings.COLLISION_RADIUS * this.settings.SYMBOL_SCALE), point.angle, this.settings)
        const line = this.paper.line(startPosition.x, startPosition.y, endPosition.x, endPosition.y)
        line.setAttribute('stroke', this.settings.LINE_COLOR)
        line.setAttribute('stroke-width', 0.5 * (this.settings.CUSPS_STROKE * this.settings.SYMBOL_SCALE))
        wrapper.appendChild(line)
      }

      // draw symbol
      const symbol = this.paper.getSymbol(point.name, point.x, point.y)
      symbol.setAttribute('id', this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_POINTS + '-' + point.name)
      wrapper.appendChild(symbol)
    }, this)

    // Descriptions and degrees/minutes are drawn in a second pass, after every planet symbol is
    // already in place. Planets often sit close together (e.g. a stellium), and appending each
    // planet's text right after its own symbol - in a single pass - meant the NEXT planet's
    // symbol (added later in that same pass) could end up drawn on top of, and hiding, the
    // previous planet's degrees/minutes text. Doing all the symbols first guarantees every
    // degree/minute label stays visible above every symbol, however close two planets are.
    this.locatedPoints.forEach(function (point: LocatedPoint) {
      // draw point descriptions
      const zodiac = new Zodiac(this.data.cusps, this.settings)
      const isRetrograde = Boolean(this.data.planets[point.name][1] && zodiac.isRetrograde(this.data.planets[point.name][1]))

      let textsToShow: string[] = []
      if (!this.settings.SHOW_DEGREES_MINUTES) {
        // legacy plain-text description (degree-in-sign + retrograde marker); superseded by
        // the stacked degrees/minutes/retrograde block below when SHOW_DEGREES_MINUTES is on,
        // so it's skipped here to avoid rendering the same information twice.
        textsToShow.push((Math.floor(this.data.planets[point.name][0]) % 30).toString())
        textsToShow.push(isRetrograde ? 'R' : '')
      }

      if (this.settings.SHOW_DIGNITIES_TEXT)
        textsToShow = textsToShow.concat(zodiac.getDignities({ name: point.name, position: this.data.planets[point.name][0] }, this.settings.DIGNITIES_EXACT_EXALTATION_DEFAULT).join(','))

      if (textsToShow.length > 0) {
        // when the degrees/minutes block occupies the area above-right of the symbol, push any
        // remaining description (e.g. dignities) below the symbol instead, so they don't overlap
        const descriptionAnchor = this.settings.SHOW_DEGREES_MINUTES
          ? { x: point.x, y: point.y + (this.settings.DEGREES_MINUTES_TEXT_SIZE * this.settings.SYMBOL_SCALE) }
          : point
        const pointDescriptions = getDescriptionPosition(descriptionAnchor, textsToShow, this.settings)
        pointDescriptions.forEach(function (dsc) {
          wrapper.appendChild(this.paper.text(dsc.text, dsc.x, dsc.y, this.settings.POINTS_TEXT_SIZE, this.settings.SIGNS_COLOR))
        }, this)
      }

      // draw degrees/minutes next to the symbol: degrees on the baseline (e.g. "19"), minutes as
      // a smaller superscript above the degrees (e.g. "31"), and - when retrograde - the \u211E
      // symbol stacked above the minutes. No ° or ' symbols are rendered.
      if (this.settings.SHOW_DEGREES_MINUTES) {
        const { degrees, minutes } = getDegreesAndMinutes(this.data.planets[point.name][0])
        const layout = getDegreesMinutesLayout(point, degrees, this.settings)

        const degreesEl = this.paper.text(degrees, layout.degrees.x, layout.degrees.y, layout.degrees.fontSize.toString(), this.settings.SIGNS_COLOR)
        degreesEl.setAttribute('text-anchor', 'start')
        wrapper.appendChild(degreesEl)

        const minutesEl = this.paper.text(minutes, layout.minutes.x, layout.minutes.y, layout.minutes.fontSize.toString(), this.settings.SIGNS_COLOR)
        minutesEl.setAttribute('text-anchor', 'start')
        wrapper.appendChild(minutesEl)

        if (isRetrograde) {
          const retrogradeEl = this.paper.text('\u211E', layout.retrograde.x, layout.retrograde.y, layout.retrograde.fontSize.toString(), this.settings.SIGNS_COLOR)
          retrogradeEl.setAttribute('text-anchor', 'start')
          wrapper.appendChild(retrogradeEl)
        }
      }
    }, this)
  }

  /**
   * The As/Ds/Mc/Ic glyphs (@see svg.ts ascendant/descendant/mediumCoeli/immumCoeli) each bake
   * their own internal x/y shift into the path data to visually center the multi-stroke letter
   * shape around the point passed to them - so the raw anchor point used to place the symbol is
   * NOT where the letters actually render. These offsets (measured from that raw anchor, at
   * SYMBOL_SCALE 1) describe each glyph's actual visual footprint, so the degrees/minutes block
   * can be anchored to the right edge or bottom edge of the rendered letters instead of to a
   * point that might sit to their left or above them.
   */
  private static readonly AXIS_GLYPH_METRICS: Record<'As' | 'Ds' | 'Mc' | 'Ic', { rightEdge: number; bottomEdge: number; hCenter: number; vCenter: number }> = {
    As: { rightEdge: 12, bottomEdge: 4.19, hCenter: 3.27, vCenter: -1.72 },
    Ds: { rightEdge: 22, bottomEdge: 5.19, hCenter: 13.28, vCenter: -0.72 },
    Mc: { rightEdge: 19, bottomEdge: 1.52, hCenter: 10.21, vCenter: -3.75 },
    Ic: { rightEdge: 19, bottomEdge: 8.65, hCenter: 13.26, vCenter: 2.3 }
  }

  /**
   * Adjusts a raw axis anchor point into one aligned with the given angle's actual rendered
   * glyph, so the degrees/minutes block sits right next to (direction 'right') or below
   * (direction 'below') the visible letters rather than overlapping or missing them.
   * @see AXIS_GLYPH_METRICS
   */
  getAxisSymbolAnchor(key: 'As' | 'Ds' | 'Mc' | 'Ic', textPosition: { x: number; y: number }, direction: 'right' | 'below'): { x: number; y: number } {
    const metrics = Radix.AXIS_GLYPH_METRICS[key]
    const scale = this.settings.SYMBOL_SCALE

    if (direction === 'below') {
      return { x: textPosition.x + (metrics.hCenter * scale), y: textPosition.y + (metrics.bottomEdge * scale) }
    }

    return { x: textPosition.x + (metrics.rightEdge * scale), y: textPosition.y + (metrics.vCenter * scale) }
  }

  drawAxis(): void {
    if (this.data.cusps == null) {
      return
    }

    const universe = this.universe
    const wrapper = getEmptyWrapper(universe, this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_AXIS, this.paper.root.id)

    const axisRadius = this.radius + ((this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO) / 4)

    const AS = 0
    const IC = 3
    const DC = 6
    const MC = 9
    let overlapLine
    let startPosition
    let endPosition

    [AS, IC, DC, MC].forEach(function (i) {
      let textPosition
      // overlap
      startPosition = getPointPosition(this.cx, this.cy, this.radius, this.data.cusps[i] + this.shift, this.settings)
      endPosition = getPointPosition(this.cx, this.cy, axisRadius, this.data.cusps[i] + this.shift, this.settings)
      overlapLine = this.paper.line(startPosition.x, startPosition.y, endPosition.x, endPosition.y)
      overlapLine.setAttribute('stroke', this.settings.AXIS_LINE_COLOR)
      overlapLine.setAttribute('stroke-width', (this.settings.SYMBOL_AXIS_STROKE * this.settings.SYMBOL_SCALE))
      wrapper.appendChild(overlapLine)

      // As
      if (i === AS) {
        // Text
        textPosition = getPointPosition(this.cx, this.cy, axisRadius + (20 * this.settings.SYMBOL_SCALE), this.data.cusps[i] + this.shift, this.settings)
        wrapper.appendChild(this.paper.getSymbol(this.settings.SYMBOL_AS, textPosition.x, textPosition.y))
        this.drawAngleDegreesMinutes(wrapper, 'As', this.getAxisSymbolAnchor('As', textPosition, 'below'), 'below')
      }

      // Ds
      if (i === DC) {
        // Text
        textPosition = getPointPosition(this.cx, this.cy, axisRadius + (2 * this.settings.SYMBOL_SCALE), this.data.cusps[i] + this.shift, this.settings)
        wrapper.appendChild(this.paper.getSymbol(this.settings.SYMBOL_DS, textPosition.x, textPosition.y))
        this.drawAngleDegreesMinutes(wrapper, 'Ds', this.getAxisSymbolAnchor('Ds', textPosition, 'below'), 'below')
      }

      // Ic
      if (i === IC) {
        // Text
        textPosition = getPointPosition(this.cx, this.cy, axisRadius + (10 * this.settings.SYMBOL_SCALE), this.data.cusps[i] - 2 + this.shift, this.settings)
        wrapper.appendChild(this.paper.getSymbol(this.settings.SYMBOL_IC, textPosition.x, textPosition.y))
        this.drawAngleDegreesMinutes(wrapper, 'Ic', this.getAxisSymbolAnchor('Ic', textPosition, 'right'), 'right')
      }

      // Mc
      if (i === MC) {
        // Text
        textPosition = getPointPosition(this.cx, this.cy, axisRadius + (10 * this.settings.SYMBOL_SCALE), this.data.cusps[i] + 2 + this.shift, this.settings)
        wrapper.appendChild(this.paper.getSymbol(this.settings.SYMBOL_MC, textPosition.x, textPosition.y))
        this.drawAngleDegreesMinutes(wrapper, 'Mc', this.getAxisSymbolAnchor('Mc', textPosition, 'right'), 'right')
      }
    }, this)
  }

  /**
   * Draws the degree/minute block (baseline degrees + superscript minutes, same layout used
   * for planets) next to an angle's (As/Ds/Mc/Ic) symbol - but only when that angle was added
   * via addPointsOfInterest() using the extended {longitude, degree, minute} format.
   * @param {'right' | 'below'} [direction] - As/Ds show it below their symbol, Mc/Ic to the side
   * @see addPointsOfInterest
   */
  drawAngleDegreesMinutes(wrapper: Element, key: string, point: { x: number; y: number }, direction: 'right' | 'below' = 'right'): void {
    const info = this.pointsOfInterestDegreesMinutes[key]
    if (info == null) {
      return
    }

    const { degrees, minutes } = formatDegreesMinutesValues(info.degree, info.minute)
    const layout = getDegreesMinutesLayout(point, degrees, this.settings, direction)

    const degreesEl = this.paper.text(degrees, layout.degrees.x, layout.degrees.y, layout.degrees.fontSize.toString(), this.settings.SIGNS_COLOR)
    degreesEl.setAttribute('text-anchor', 'start')
    wrapper.appendChild(degreesEl)

    const minutesEl = this.paper.text(minutes, layout.minutes.x, layout.minutes.y, layout.minutes.fontSize.toString(), this.settings.SIGNS_COLOR)
    minutesEl.setAttribute('text-anchor', 'start')
    wrapper.appendChild(minutesEl)
  }

  /**
   * Draw cusps
   */
  drawCusps(): void {
    if (this.data.cusps == null) {
      return
    }

    const universe = this.universe
    const wrapper = getEmptyWrapper(universe, this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_CUSPS, this.paper.root.id)

    const numbersRadius = this.radius / this.settings.INDOOR_CIRCLE_RADIUS_RATIO + (this.settings.COLLISION_RADIUS * this.settings.SYMBOL_SCALE)

    // Boundary between the ruler/planets area and the signs ring (same radius used for
    // the "inner circle" and for the outer edge of the sign color segments). Extending
    // house lines up to here (instead of the true outer circle) keeps them from ever
    // crossing into - or overlapping - the zodiac sign glyphs, matching astro.com style.
    const outerHouseLineRadius = this.radius - (this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO)
    const innerHouseLineRadius = this.radius / this.settings.INDOOR_CIRCLE_RADIUS_RATIO
    const defaultHouseLineRadius = this.radius - (this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO + this.rulerRadius)

    // The four angles (As/Ic/Ds/Mc) always sit at cusps 0/3/6/9 (@see drawAxis) and get a
    // slightly thicker, darker line than the regular houses so they stand out.
    const AS = 0
    const IC = 3
    const DC = 6
    const MC = 9
    const mainAxis = [AS, IC, DC, MC]

    // Cusps
    for (let i = 0, ln = this.data.cusps.length; i < ln; i++) {
      // House division lines are always drawn as a single, unbroken line - regardless of
      // any planet symbol that may sit along the way. This wrapper is appended to the
      // universe before drawPoints() draws the planets (@see chart.ts), so the lines sit
      // visually behind the symbols instead of being cut short around them.
      const start = getPointPosition(this.cx, this.cy, innerHouseLineRadius, this.data.cusps[i] + this.shift, this.settings)
      const end = getPointPosition(this.cx, this.cy, this.settings.CUSPS_LINES_TO_OUTER_CIRCLE ? outerHouseLineRadius : defaultHouseLineRadius, this.data.cusps[i] + this.shift, this.settings)

      const newLine = this.paper.line(start.x, start.y, end.x, end.y)
      if (mainAxis.includes(i)) {
        newLine.setAttribute('stroke', this.settings.AXIS_LINE_COLOR)
        newLine.setAttribute('stroke-width', (this.settings.SYMBOL_AXIS_STROKE * this.settings.SYMBOL_SCALE).toString())
      } else {
        newLine.setAttribute('stroke', this.settings.LINE_COLOR)
        newLine.setAttribute('stroke-width', (this.settings.HOUSES_STROKE * this.settings.SYMBOL_SCALE).toString())
      }
      wrapper.appendChild(newLine)

      // Cup number
      const deg360 = radiansToDegree(2 * Math.PI)
      const startOfCusp = this.data.cusps[i]
      const endOfCusp = this.data.cusps[(i + 1) % 12]
      const gap = endOfCusp - startOfCusp > 0 ? endOfCusp - startOfCusp : endOfCusp - startOfCusp + deg360
      const textPosition = getPointPosition(this.cx, this.cy, numbersRadius, ((startOfCusp + gap / 2) % deg360) + this.shift, this.settings)
      wrapper.appendChild(this.paper.getSymbol((i + 1).toString(), textPosition.x, textPosition.y))
    }
  }

  /**
   * Draw aspects
   *
   * @param {Array<Object> | null} [customAspects] - optional externally computed aspects list to draw as-is.
   *   When provided, the internal aspect calculation (and the settings.ASPECTS orbit configuration) is skipped entirely.
   *   When omitted (or null), aspects are calculated internally using settings.ASPECTS (degree/orbit/color per aspect type).
   * @return {Radix}
   */
  aspects(customAspects?: FormedAspect[] | null): Radix {
    const aspectsList = customAspects != null && Array.isArray(customAspects)
      ? customAspects
      : new AspectCalculator(this.toPoints, this.settings).radix(this.data.planets)

    const universe = this.universe
    const wrapper = getEmptyWrapper(universe, this.paper.root.id + '-' + this.settings.ID_ASPECTS, this.paper.root.id)

    const duplicateCheck: string[] = []

    for (let i = 0, ln = aspectsList.length; i < ln; i++) {
      const key = aspectsList[i].aspect.name + '-' + aspectsList[i].point.name + '-' + aspectsList[i].toPoint.name
      const opositeKey = aspectsList[i].aspect.name + '-' + aspectsList[i].toPoint.name + '-' + aspectsList[i].point.name
      if (!duplicateCheck.includes(opositeKey)) {
        duplicateCheck.push(key)

        const startPoint = getPointPosition(this.cx, this.cy, this.radius / this.settings.INDOOR_CIRCLE_RADIUS_RATIO, aspectsList[i].toPoint.position + this.shift, this.settings)
        const endPoint = getPointPosition(this.cx, this.cy, this.radius / this.settings.INDOOR_CIRCLE_RADIUS_RATIO, aspectsList[i].point.position + this.shift, this.settings)

        const line = this.paper.line(startPoint.x, startPoint.y, endPoint.x, endPoint.y)
        line.setAttribute('stroke', this.settings.STROKE_ONLY ? this.settings.LINE_COLOR : aspectsList[i].aspect.color)
        line.setAttribute('stroke-width', (this.settings.ASPECTS_STROKE * this.settings.SYMBOL_SCALE).toString())

        line.setAttribute('data-name', aspectsList[i].aspect.name)
        line.setAttribute('data-degree', aspectsList[i].aspect.degree.toString())
        line.setAttribute('data-point', aspectsList[i].point.name)
        line.setAttribute('data-toPoint', aspectsList[i].toPoint.name)
        line.setAttribute('data-precision', aspectsList[i].precision.toString())

        wrapper.appendChild(line)
      }
    }

    return this.context
  }

  /**
   * Add points of interest for aspects calculation
   * @param {Object} points - either the legacy format, e.g. {"As":[0],"Ic":[90],"Ds":[180],"Mc":[270]},
   *   or the extended format that also carries the degree/minute-in-sign to display next to the
   *   angle's symbol, e.g. {"As": {longitude: 43.3994, degree: 13, minute: 24}}.
   *   When degree and minute are both provided, they're drawn using the same baseline+superscript
   *   layout used for planets (@see drawAxis). The legacy array format never displays them.
   * @see (this.settings.AspectCalculator( toPoints) )
   */
  addPointsOfInterest(points: PointsOfInterestInput): Radix {
    for (const point in points) {
      if (points.hasOwnProperty(point)) {
        const value = points[point]

        if (Array.isArray(value)) {
          this.toPoints[point] = value
          delete this.pointsOfInterestDegreesMinutes[point]
        } else {
          this.toPoints[point] = [value.longitude]

          if (typeof value.degree === 'number' && typeof value.minute === 'number') {
            this.pointsOfInterestDegreesMinutes[point] = { degree: value.degree, minute: value.minute }
          } else {
            delete this.pointsOfInterestDegreesMinutes[point]
          }
        }
      }
    }

    // chart.radix() already calls drawAxis() once, before addPointsOfInterest() can possibly
    // run (it's called separately, afterwards, by the consumer). Re-draw the axis here so any
    // degree/minute info just added actually shows up next to the As/Ds/Mc/Ic symbols instead
    // of being silently ignored because it arrived after the first (and, until now, only) draw.
    this.drawAxis()

    return this.context
  }

  drawRuler(): void {
    const universe = this.universe
    const wrapper = getEmptyWrapper(universe, this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_RULER, this.paper.root.id)

    const startRadius = (this.radius - (this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO + this.rulerRadius))
    const rays = getRulerPositions(this.cx, this.cy, startRadius, startRadius + this.rulerRadius, this.shift, this.settings)

    rays.forEach(function (ray) {
      const line = this.paper.line(ray.startX, ray.startY, ray.endX, ray.endY)
      line.setAttribute('stroke', this.settings.CIRCLE_COLOR)
      line.setAttribute('stroke-width', (this.settings.CUSPS_STROKE * this.settings.SYMBOL_SCALE))
      wrapper.appendChild(line)
    }, this)

    const circle = this.paper.circle(this.cx, this.cy, startRadius)
    circle.setAttribute('stroke', this.settings.CIRCLE_COLOR)
    circle.setAttribute('stroke-width', (this.settings.CUSPS_STROKE * this.settings.SYMBOL_SCALE).toString())
    wrapper.appendChild(circle)
  }

  /**
   * Draw circles
   */
  drawCircles(): void {
    const universe = this.universe
    const wrapper = getEmptyWrapper(universe, this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_CIRCLES, this.paper.root.id)

    // indoor circle
    let circle = this.paper.circle(this.cx, this.cy, this.radius / this.settings.INDOOR_CIRCLE_RADIUS_RATIO)
    circle.setAttribute('stroke', this.settings.CIRCLE_COLOR)
    circle.setAttribute('stroke-width', (this.settings.CIRCLE_STRONG * this.settings.SYMBOL_SCALE).toString())
    wrapper.appendChild(circle)

    // outdoor circle
    circle = this.paper.circle(this.cx, this.cy, this.radius)
    circle.setAttribute('stroke', this.settings.CIRCLE_COLOR)
    circle.setAttribute('stroke-width', (this.settings.CIRCLE_STRONG * this.settings.SYMBOL_SCALE).toString())
    wrapper.appendChild(circle)

    // inner circle
    circle = this.paper.circle(this.cx, this.cy, this.radius - this.radius / this.settings.INNER_CIRCLE_RADIUS_RATIO)
    circle.setAttribute('stroke', this.settings.CIRCLE_COLOR)
    circle.setAttribute('stroke-width', (this.settings.CIRCLE_STRONG * this.settings.SYMBOL_SCALE).toString())
    wrapper.appendChild(circle)
  }

  /**
   * Display transit horoscope
   *
   * @param {Object} data
   * @example
   *  {
   *    "planets":{"Moon":[0], "Sun":[30],  ... },
   *    "cusps":[300, 340, 30, 60, 75, 90, 116, 172, 210, 236, 250, 274],  *
   *  }
   *
   * @return {Transit} transit
   */
  transit(data: AstroData): Transit {
    // remove axis (As, Ds, Mc, Ic) from radix
    getEmptyWrapper(this.universe, this.paper.root.id + '-' + this.settings.ID_RADIX + '-' + this.settings.ID_AXIS, this.paper.root.id)
    const transit = new Transit(this.context, data, this.settings)
    transit.drawBg()
    transit.drawPoints()
    transit.drawCusps()
    transit.drawRuler()
    transit.drawCircles()
    return transit
  }
}

export default Radix
