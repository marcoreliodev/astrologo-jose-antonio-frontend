import Chart from "./chart"

describe.only('constructor', () => {
  test('should throw error when empty houses', () => {
    const chart = new Chart('paper', 1, 1)

    expect(() => {
      chart.radix({planets: {}, cusps: []})
    }).toThrowError(`Count of 'cusps' values has to be 12.`)
  })

  test('should throw error when houses are less than 12', () => {
    const chart = new Chart('paper', 1, 1)

    expect(() => {
      chart.radix({planets: {}, cusps: [1, 2, 3]})
    }).toThrowError(`Count of 'cusps' values has to be 12.`)
  })

  test('addPointsOfInterest() called after chart.radix() should still render the angle degrees/minutes (chart.radix() already draws the axis once, before addPointsOfInterest can run)', () => {
    document.body.innerHTML = '<div id="chart2"></div>';
    const chart = new Chart('chart2', 500, 500)
    const cusps = [43.3994, 72.5635, 102.0653, 132.7834, 164.5653, 195.3935, 223.3994, 252.5635, 282.0653, 312.7834, 344.5653, 15.3935]
    const radix = chart.radix({ planets: { Sun: [99.4, 1] }, cusps })

    // mirrors real-world usage: addPointsOfInterest() is called AFTER chart.radix(), i.e. after
    // the axis has already been drawn once internally by chart.radix()
    radix.addPointsOfInterest({
      As: { longitude: cusps[0], degree: 13, minute: 24 },
      Ic: { longitude: cusps[3], degree: 12, minute: 47 },
      Ds: { longitude: cusps[6], degree: 13, minute: 24 },
      Mc: { longitude: cusps[9], degree: 12, minute: 47 },
    })

    const texts = Array.from(document.querySelectorAll('#chart2-astrology-radix-axis > text')).map((t) => t.textContent)
    expect(texts).toEqual(expect.arrayContaining(['13', '24', '12', '47']))
  })

})